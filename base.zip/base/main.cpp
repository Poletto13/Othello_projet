#include <iostream>
#include <map>
#include <vector>
#include <cstdio>
#include <cstdlib>
#include <string>
#include "console.h"
#include "Joueur.h"
#include <conio.h>
#include <windows.h>
using namespace std;

void Nouvelle_Partie(Console*p)
{
    Joueur j;

    string nom;
    cout<<"Entrez votre nom de joueur : ";
    cin>>nom;
    j.get_nom()=nom;

    system("cls");

    //vector <vector<int>> othellier;

    cout<<"\n  ABCDEFGH\n 1\n 2\n 3\n 4\n 5\n 6\n 7\n 8";

    /*int a = 254;
    char b = a;
    p->setColor(COLOR_WHITE);
    cout<<b;
    p->setColor(COLOR_GREEN);*/

    Console* pt = NULL;
    pt = Console::getInstance();

    int touche;
    int ligne_joueur=2;
    int colonne_joueur=2;
    char c;

    do
    {
    pt->gotoLigCol(ligne_joueur, colonne_joueur); //position du curseur

        if (pt->isKeyboardPressed())
            {
                touche=pt->getInputKey(); //prend en compte la touche enfonc�e

                switch (touche)
                {
                case'z': //deplacement vers le haut
                        ligne_joueur = ligne_joueur-1;
                        if(ligne_joueur<2)
                            ligne_joueur++;
                        break;
                case's': //deplacement vers le bas
                        ligne_joueur = ligne_joueur+1;
                        if(ligne_joueur>9)
                            ligne_joueur--;
                        break;
                case 'q': //deplacement vers la gauche
                        colonne_joueur = colonne_joueur-1;
                        if(colonne_joueur<2)
                            colonne_joueur++;
                        break;
                case 'd': //deplacement vers la droite
                        colonne_joueur = colonne_joueur+1;
                        if(colonne_joueur>9)
                            colonne_joueur--;
                        break;
                }

            }

    pt->gotoLigCol(11,1);
    if (colonne_joueur==2)
        c='A';
    if (colonne_joueur==3)
        c='B';
    if (colonne_joueur==4)
        c='C';
    if (colonne_joueur==5)
        c='D';
    if (colonne_joueur==6)
        c='E';
    if (colonne_joueur==7)
        c='F';
    if (colonne_joueur==8)
        c='G';
    if (colonne_joueur==9)
        c='H';

    cout<<"position : "<<ligne_joueur-1<<","<<c<<endl;


    }

    while(touche!='p'); //quitter



}


int main()
{
    Console* c = NULL; //pointeur console
    c =  Console::getInstance();
    c->setColor(COLOR_GREEN);

    char choix;
    do
    {
        system("cls"); //efface la console

        //Affichage menu
        cout << endl << "\t***********\n\t* OTHELLO *\n\t***********" << endl<< endl;
        cout << "\t1. Nouvelle partie" << endl;
        cout << "\t2. Continuer" << endl;
        cout << "\t3. Quitter" << endl << endl;
        do
        {
            cin.clear();
            cin >> choix; //recupere le choix utilisateur
        }
        while (choix !='1' && choix !='2' && choix !='3');   //nouvelle saisie si le choix ne correspond pas

        if(choix == '1')
        {
            system("cls");
            Nouvelle_Partie(c);//Appel du sous programme
        }
        else if(choix == '2')
        {
            system("cls");
            //Appel du sous programme
        }
        else if(choix == '3')
        {
            exit(0); //fin du programme
        }

    }
    while(choix !='1' && choix!='2' && choix!='3');

    return 0;
}
